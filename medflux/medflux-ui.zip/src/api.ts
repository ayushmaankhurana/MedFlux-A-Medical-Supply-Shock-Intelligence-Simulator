import axios from 'axios';
import {
  NetworkNode,
  NetworkEdge,
  ScenarioSettings,
  SimulationResult } from
'./types';

export const simulateNetwork = async (
settings: ScenarioSettings,
nodes: NetworkNode[],
edges: NetworkEdge[])
: Promise<SimulationResult> => {
  const payload = {
    scenario_settings: {
      budget: settings.budget,
      shock_type_selected: settings.shock_type_selected,
      specific_resource: settings.specific_resource,
      shelf_life_days: settings.shelf_life_days,
      shocked_node_id: settings.shocked_node_id,
      shock_magnitude: settings.shock_magnitude,
      simulation_steps: 30
    },
    nodes: nodes.map((n) => ({
      id: n.id,
      type: n.type,
      inventory: n.inventory,
      processing_duration: n.processing_duration,
      max_capacity: n.max_capacity,
      demand: n.demand,
      fixed_upgrade_cost: n.fixed_upgrade_cost,
      upgrade_capacity_boost: n.upgrade_capacity_boost,
      holding_cost_per_unit: n.holding_cost_per_unit,
      is_shocked: n.id === settings.shocked_node_id
    })),
    edges: edges.map((e) => ({
      source: e.source,
      target: e.target,
      capacity: e.capacity,
      delivery_time: e.delivery_time,
      shipping_cost_per_unit: e.shipping_cost_per_unit
    }))
  };

  try {
    const res = await axios.post('http://localhost:8000/simulate', payload);
    return res.data;
  } catch (error) {
    console.warn(
      'API call failed, generating fallback mock simulation data...',
      error
    );

    // Fallback: Generate 30 days of mock timeseries data
    const timeseries = [];
    const shockedNodeId = settings.shocked_node_id;

    for (let day = 0; day <= 30; day++) {
      const dayNodes: Record<
        string,
        {inventory: number;stressIndex: number;}> =
      {};

      nodes.forEach((node) => {
        let baseStress = node.stressIndex;
        let currentInv = node.inventory;

        // Simulate shock impact
        if (node.id === shockedNodeId && day >= 2 && day <= 15) {
          baseStress = Math.min(
            100,
            baseStress + settings.shock_magnitude * 100
          );
          currentInv = Math.max(
            0,
            currentInv - currentInv * settings.shock_magnitude * 0.2
          );
        } else if (day > 15) {
          // Recovery phase
          baseStress = Math.max(0, baseStress - (day - 15) * 2);
          currentInv = Math.min(node.max_capacity, currentInv + 100);
        }

        // Ripple effect to downstream (hospitals)
        if (node.type === 'hospital' && day > 5 && day <= 20) {
          if (settings.shock_magnitude > 0.5) {
            baseStress = Math.min(100, baseStress + 20);
            currentInv = Math.max(0, currentInv - 50);
          }
        }

        dayNodes[node.id] = {
          inventory: Math.floor(currentInv),
          stressIndex: Math.floor(baseStress)
        };
      });

      timeseries.push({ day, nodes: dayNodes });
    }

    // Calculate mock metrics based on shock
    const peakShortage =
    settings.shock_magnitude > 0.3 ?
    Math.floor(settings.shock_magnitude * 5000) :
    0;
    const recoveryTime =
    settings.shock_magnitude > 0.3 ?
    12 + Math.floor(settings.shock_magnitude * 10) :
    0;

    return {
      baseline: {
        timeseries,
        metrics: {
          recovery_time: recoveryTime,
          peak_shortage: peakShortage
        }
      },
      optimization_plan: {
        recommendations: [
        `Increase buffer capacity at ${nodes.find((n) => n.type === 'manufacturer')?.name || 'Manufacturer'} by 25%`,
        `Diversify supplier network for ${settings.specific_resource}`,
        `Pre-position inventory closer to high-demand hospitals`]

      }
    };
  }
};